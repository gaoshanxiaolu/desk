/*
  * Copyright (c) 2013 Qualcomm Atheros, Inc..
  * All Rights Reserved.
  * Qualcomm Atheros Confidential and Proprietary.
  */

#if defined(P2P_ENABLED)
extern void swat_wmiconfig_p2p(int argc, char *argv[]);
#endif

